package com.myweb.lab7dialogrv

data class Student(val id:String, val  name:String, val age:Int){

}